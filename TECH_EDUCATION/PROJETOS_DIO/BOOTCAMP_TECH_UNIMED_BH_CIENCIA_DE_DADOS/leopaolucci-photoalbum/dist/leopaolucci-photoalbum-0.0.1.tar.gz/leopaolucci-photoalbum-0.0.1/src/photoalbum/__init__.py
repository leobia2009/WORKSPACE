from importlib import resources
try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib

# Version of the photoalbum_leopaolucci package
__version__ = "0.0.1"

