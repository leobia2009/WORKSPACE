# 					leopaolucci-photoalbum



### Description 

#### The package leopaolucci-photoalbum is used to:

is used to assemble a photo album based on images available in a directory of the user's choice. The images are converted to the standard "pdf", saved in a file in a directory of the user's choice.



### Installation

Use the package manager "pip" to install leopaolucci-photoalbum.

​						**pip install leopaolucci-photoalbum**

 **Usage**

After installing the package, the  **photoalbum**  command will be available on the command line.

This command calls the module **main.py** . 



**Author**

Leopoldo Augusto Paolucci

### License

This project is under the MIT license. 

Open the [**LICENSE**] file in your package directory for more details.

